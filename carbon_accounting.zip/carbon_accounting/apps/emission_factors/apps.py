from django.apps import AppConfig


class EmissionFactorsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.emission_factors'
