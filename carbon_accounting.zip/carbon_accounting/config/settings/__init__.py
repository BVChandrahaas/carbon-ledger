# Import local settings by default
from .local import *
