import streamlit as st
import pandas as pd
import io

st.set_page_config(page_title="Upload Data", page_icon="📤", layout="centered")

st.title("📤 Bulk Data Upload")

if 'org_id' not in st.session_state:
    st.warning("Please select an organization in the Home page first.")
else:
    api = st.session_state.api
    org_id = st.session_state.org_id

    st.markdown("""
    Upload a CSV file to import multiple emission records at once.
    The file must follow the specific template.
    """)
    
    # Download Template
    template_data = {
        'facility_id': ['(facility_uuid)', '(facility_uuid)'],
        'scope': ['scope1', 'scope2'],
        'category': ['Diesel', 'Electricity'],
        'subcategory': ['Stationary', 'Grid'],
        'quantity': [100.5, 500],
        'unit': ['liter', 'kWh'],
        'emission_factor_used': [2.687, 0.712],
        'activity_date': ['2024-01-15', '2024-01-15'],
        'notes': ['Jan utility bill', 'Jan meter reading']
    }
    df_template = pd.DataFrame(template_data)
    csv = df_template.to_csv(index=False).encode('utf-8')
    
    st.download_button(
        "Download CSV Template",
        csv,
        "emissions_template.csv",
        "text/csv",
        key='download-csv'
    )

    st.divider()

    uploaded_file = st.file_uploader("Choose a CSV file", type="csv")
    
    if uploaded_file is not None:
        if st.button("Process & Upload"):
            with st.spinner("Processing file..."):
                try:
                    # Upload and process
                    result = api.upload_bulk_csv(org_id, uploaded_file)
                    st.success(f"Upload completed! Status: {result['processing_status']}")
                    if result['records_created'] > 0:
                        st.info(f"Records created: {result['records_created']}")
                    if result['error_message']:
                        st.error(f"Error: {result['error_message']}")
                except Exception as e:
                    st.error(f"Upload failed: {e}")
