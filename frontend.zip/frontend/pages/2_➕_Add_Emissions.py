import streamlit as st
import datetime

st.set_page_config(page_title="Add Emissions", page_icon="➕", layout="centered")

st.title("➕ Record Emission Activity")

if 'org_id' not in st.session_state:
    st.warning("Please select an organization in the Home page first.")
else:
    api = st.session_state.api
    org_id = st.session_state.org_id

    st.subheader("Activity Details")
    
    # 1. Facility Selection (Moved outside form for reactivity)
    facilities = api.get_facilities(org_id)
    fac_names = {f['name']: f['id'] for f in facilities['results']}
    selected_fac = st.selectbox("Select Facility", list(fac_names.keys()))
    
    # 2. Category & Factor (Moved outside form for reactivity)
    efs = api.get_emission_factors()
    def get_label(f):
        sub = f" - {f['subcategory']}" if f['subcategory'] else ""
        return f"{f['category']}{sub} ({f['unit']}) [{f['region']}]"

    ef_options = {get_label(f): f for f in efs['results']}
    sorted_labels = sorted(ef_options.keys(), key=lambda x: ef_options[x]['scope'])
    
    selected_ef_label = st.selectbox("Select Activity Type", sorted_labels)
    selected_ef = ef_options[selected_ef_label]

    # --- Data Entry Form ---
    with st.form("emission_submission_form", clear_on_submit=True):
        # 3. Dynamic Quantity Label
        st.info(f"Selected: **{selected_ef_label}**")
        
        quantity = st.number_input(
            f"Enter Quantity in {selected_ef['unit']}", 
            min_value=0.0, 
            format="%.4f",
            help=f"Factor: {selected_ef['emission_factor_co2e']} kg CO2e / {selected_ef['unit']}"
        )
        
        # 4. Date
        activity_date = st.date_input("Activity Date", datetime.date.today())
        
        # 5. Notes
        notes = st.text_area("Notes", placeholder="Reference, bill #, etc.")
        
        submit = st.form_submit_button("Calculate & Save Record")
        
        if submit:
            try:
                data = {
                    'organization': org_id,
                    'facility': fac_names[selected_fac],
                    'scope': selected_ef['scope'],
                    'category': selected_ef['category'],
                    'subcategory': selected_ef['subcategory'],
                    'quantity': quantity,
                    'unit': selected_ef['unit'],
                    'emission_factor_used': selected_ef['emission_factor_co2e'],
                    'emission_factor': selected_ef['id'],
                    'activity_date': activity_date.isoformat(),
                    'notes': notes,
                    'data_source': 'manual_entry'
                }
                
                result = api.create_emission_record(data)
                st.success(f"Successfully recorded! Calculated: **{result['co2e_calculated']} kg CO2e**")
                
            except Exception as e:
                if hasattr(e, 'response') and e.response is not None:
                    try:
                        error_detail = e.response.json()
                        st.error(f"Backend Validation Error: {error_detail}")
                    except:
                        st.error(f"Error saving record: {e}")
                else:
                    st.error(f"Error saving record: {e}")
