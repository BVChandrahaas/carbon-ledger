import streamlit as st
import plotly.express as px
import pandas as pd

st.set_page_config(page_title="Dashboard", page_icon="📊", layout="wide")

st.title("📊 Emissions Dashboard")

if 'org_id' not in st.session_state:
    st.warning("Please select an organization in the Home page first.")
else:
    api = st.session_state.api
    org_id = st.session_state.org_id

    # --- Filters ---
    col1, col2 = st.columns(2)
    with col1:
        is_consolidated = st.checkbox("Show Consolidated All-Time View")
        
    with col2:
        if is_consolidated:
            period = None
            st.info("📊 Viewing consolidated data across all periods.")
        else:
            selected_date = st.date_input("Select Month", value=pd.to_datetime("2024-01-01"))
            period = selected_date.strftime('%Y-%m')
            st.info(f"📅 Viewing data for period: **{period}**")

    # --- Fetch Data ---
    try:
        stats = api.get_dashboard_stats(org_id, period)
        
        # --- Metric Cards ---
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Emissions (kg CO2e)", f"{float(stats['total_emissions']):,.2f}")
        m2.metric("Scope 1", f"{float(stats['scope1']):,.2f}")
        m3.metric("Scope 2", f"{float(stats['scope2']):,.2f}")
        m4.metric("Scope 3", f"{float(stats['scope3']):,.2f}")

        st.divider()

        # --- Visualizations ---
        c1, c2 = st.columns(2)
        
        with c1:
            st.subheader("Emissions by Scope")
            scope_data = pd.DataFrame({
                'Scope': ['Scope 1', 'Scope 2', 'Scope 3'],
                'Emissions': [float(stats['scope1']), float(stats['scope2']), float(stats['scope3'])]
            })
            
            # Custom Color Mapping
            color_map = {
                'Scope 1': '#FF6B35', # Warm Orange
                'Scope 2': '#004E89', # Deep Blue
                'Scope 3': '#1B998B'  # Teal
            }
            
            fig_pie = px.pie(
                scope_data, 
                values='Emissions', 
                names='Scope', 
                hole=0.4,
                color='Scope',
                color_discrete_map=color_map
            )
            st.plotly_chart(fig_pie, use_container_width=True)

        with c2:
            st.subheader("Emission Records Found")
            st.info(f"The calculation for this period is based on **{stats['record_count']}** individual activity records.")
            
            # Fetch latest records
            records = api.get_emission_records(org_id)
            if records['results']:
                df_records = pd.DataFrame(records['results'])
                st.dataframe(df_records[['category', 'quantity', 'unit', 'co2e_calculated', 'activity_date']], use_container_width=True)

    except Exception as e:
        st.error(f"Error loading dashboard: {e}")
