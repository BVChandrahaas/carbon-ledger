import streamlit as st
from utils.api_client import APIClient

# Page configuration
st.set_page_config(
    page_title="Carbon Accounting MVP",
    page_icon="🌱",
    layout="wide",
)

# Initialize API Client
if 'api' not in st.session_state:
    st.session_state.api = APIClient()

def main():
    st.title("🌱 Carbon Accounting Platform")
    
    st.markdown("""
    Welcome to the **Carbon Accounting MVP**.
    This platform helps you track, calculate, and report your organization's carbon footprint.
    
    ### 🚀 Getting Started
    1. **Select Organization**: Use the sidebar to select your company.
    2. **View Dashboard**: Check your current emissions profile.
    3. **Add Data**: Manually enter activity data or upload a CSV file.
    """)

    # --- Sidebar Configuration ---
    st.sidebar.title("Configuration")
    
    # Load Organizations
    try:
        orgs = st.session_state.api.get_organizations()
        org_names = {o['name']: o['id'] for o in orgs['results']}
        
        if org_names:
            selected_org_name = st.sidebar.selectbox("Select Organization", list(org_names.keys()))
            st.session_state.org_id = org_names[selected_org_name]
            st.session_state.org_name = selected_org_name
        else:
            st.sidebar.warning("No organizations found. Please create one in the admin panel.")
            
    except Exception as e:
        st.sidebar.error(f"Error connecting to backend: {e}")

    # --- Quick Stats ---
    if 'org_id' in st.session_state:
        st.sidebar.divider()
        st.sidebar.info(f"Connected to: **{st.session_state.org_name}**")
        
    st.info("👈 Use the sidebar to navigate between pages")

if __name__ == "__main__":
    main()
